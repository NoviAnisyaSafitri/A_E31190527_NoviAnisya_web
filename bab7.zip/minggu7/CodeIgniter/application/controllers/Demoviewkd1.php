<?php
class Demoviewkd1 extends CI_Controller{
	public function index (){
		$this->load->view('headerviewkd1');
		// $this->load->view('contentview');
		$this->load->view('footerviewkd1');
	}
}
?>