<?php

class Demo_controller extends CI_Controller{

	public function index(){
		echo "<h2>Demo Controller</h2>";
		echo "<br>Function yang di panggil adalah aksi";
	}

	public function aksi(){
		echo "<h2>Demo Controller</h2>";
		echo "<br>Function yang di panggil adalah aksi";
	}
}

?>