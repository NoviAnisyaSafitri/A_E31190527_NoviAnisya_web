<!DOCTYPE html>
<html>
<head>
	<title>NOVI ANISYA SAFITRI</title>
</head>
<body>
	<h2>Halaman Profil</h2>
	<p>Selamat datang ini adalah halaman profil</p>

</body>
</html>