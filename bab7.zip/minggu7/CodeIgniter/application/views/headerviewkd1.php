<!DOCTYPE html>
<html>
<head>
	<title>NOVI ANISYA SAFITRI Demo View</title>
</head>
<body>
	<h1>Multiple View</h1>

