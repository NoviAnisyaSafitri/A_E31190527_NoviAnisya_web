<!DOCTYPE html>
<html>
<head>
	<title>Demo View Css</title>
	<style type="text/css">
		h2{
			color :#f00;
			font-size: 20px;
			border-bottom: dashed 1px #f00;
		}
		p{
			font-style: italic;
	}
	<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>">-->

	</style>
		
</head>
<body>
	<h2>Demo View dengan CSS</h2>
	<p>contoh demo view dengan css</p>
</body>
</html>