<!DOCTYPE html>
<html>
<head>
	<title>Hello View</title>
</head>
<body>
	<h2>"Hello World PHP"</h2>

</body>
</html>