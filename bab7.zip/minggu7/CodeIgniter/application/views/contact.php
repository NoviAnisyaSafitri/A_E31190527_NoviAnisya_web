<!DOCTYPE html>
<html>
<head>
	<title>NOVI ANISYA SAFITRI</title>
</head>
<body>
	<h2>Halaman Contact</h2>
	<p>Selamat datang ini adalah halaman contact</p>

</body>
</html>