<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="UTF-8">
    <title>Kesimpulan</title>
	<meta name="Author" content=""/>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="font-size:18px;">
    Dari percobaan ini dapat disimpulkan bahwa dalam memanggil data array atau parsing data array dari Model ke Views tidak perlu dipanggil satu-satu tiap variabel atau tiap index. <br/>Cukup menggunakan perulangan <i>foreach</i> yang kemudian merubah variabel yang ada di controller untuk selanjutnya memanggil index array.
</body>
</html>
