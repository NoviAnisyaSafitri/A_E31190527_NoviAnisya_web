<?php
	class soal2_model extends CI_Model{
		public $dataku = ['data1'=>'Data variabel ke 1', 'data2'=>'Data variabel ke 2', 'data3'=>'Data variabel ke 3', 'data4'=>'Data variabel ke 4'];
	}
?>
