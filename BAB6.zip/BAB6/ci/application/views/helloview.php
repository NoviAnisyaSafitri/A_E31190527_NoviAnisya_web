<html>
<head>
	<title>Controller, Model dan View</title>
</head>
<body>
	<h2><?php echo $teks; ?></h2>
	<h3>Menggunakan Controller dan view </h3>
</body>
</html>
