<html>
	<head>
		<title>Controller dan View lebih dari 1 Variabel</title>
	</head>
	<body>
		<h2>Mengirim data dari Controller ke View</h2>

		<!-- Memanggil variabel 1-->
		variabel1: <?php echo $variabel1; ?><br>

		<!-- Memanggil variabel 2-->
		variabel2: <?php echo $variabel2; ?><br>
</html>
